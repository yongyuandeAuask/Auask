#ifndef UETOOL_H
#define UETOOL_H
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <malloc.h>
#include <math.h>
#include <thread>
#include <iostream>
#include <sys/stat.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <locale>
#include <string>
#include <codecvt>
#include <dlfcn.h>

#define PI 3.141592653589793238
typedef unsigned int ADDRESS;
typedef char PACKAGENAME;
typedef unsigned short UTF16;
typedef char UTF8;

// 全局：px/py 是半宽/半高（运行时由你的渲染层赋值，方框已证明其正确）
float matrix[16] = { 0 }, angle, camera, r_x, r_y, r_w, px, py;

void getUTF8(UTF8 * buf, unsigned long namepy)
{
    UTF16 buf16[16] = { 0 };
    driver->read(namepy, buf16, 28);
    UTF16 *pTempUTF16 = buf16;
    UTF8 *pTempUTF8 = buf;
    UTF8 *pUTF8End = pTempUTF8 + 32;
    while (pTempUTF16 < pTempUTF16 + 28)
    {
        if (*pTempUTF16 <= 0x007F && pTempUTF8 + 1 < pUTF8End) {
            *pTempUTF8++ = (UTF8) * pTempUTF16;
        } else if (*pTempUTF16 >= 0x0080 && *pTempUTF16 <= 0x07FF && pTempUTF8 + 2 < pUTF8End) {
            *pTempUTF8++ = (*pTempUTF16 >> 6) | 0xC0;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        } else if (*pTempUTF16 >= 0x0800 && *pTempUTF16 <= 0xFFFF && pTempUTF8 + 3 < pUTF8End) {
            *pTempUTF8++ = (*pTempUTF16 >> 12) | 0xE0;
            *pTempUTF8++ = ((*pTempUTF16 >> 6) & 0x3F) | 0x80;
            *pTempUTF8++ = (*pTempUTF16 & 0x3F) | 0x80;
        } else {
            break;
        }
        pTempUTF16++;
    }
}

struct Vector2A {
    float X, Y;
    Vector2A() { X = 0; Y = 0; }
    Vector2A(float x, float y) { X = x; Y = y; }
};
struct Vector3A {
    float X, Y, Z;
    Vector3A() { X = 0; Y = 0; Z = 0; }
    Vector3A(float x, float y, float z) { X = x; Y = y; Z = z; }
};
struct Vector4A {
    float X, Y, Z, W;
    Vector4A() { X = 0; Y = 0; Z = 0; W = 0; }
    Vector4A(float x, float y, float z, float w) { X = x; Y = y; Z = z; W = w; }
};
struct FMatrix { float M[4][4]; };
struct Quat { float X, Y, Z, W; };

// ★★★ 决定性修复：Translation 与 Scale3D 之间必须有 chunk ★★★
// 没有它，human 的 Scale3D 读错 → c2wMatrix 旋转缩放错 → 四肢 bone 算歪、中轴碰巧对。
struct FTransform {
    Quat     Rotation;     // 16 字节
    Vector3A Translation;  // 12 字节
    float    chunk;        //  4 字节  ← 对齐填充，必须有，否则 Scale3D 错位
    Vector3A Scale3D;      // 12 字节
};                          // 合计 44 字节

// 编译期锁死：chunk 没加成功这里会直接编译报错，再也不用看截图猜
static_assert(sizeof(Quat) == 16, "Quat must be 16 bytes");
static_assert(sizeof(FTransform) == 44, "FTransform MUST be 44 bytes: add 'float chunk;' between Translation and Scale3D");

Vector2A rotateCoord(float angle, float objRadar_x, float objRadar_y)
{
    Vector2A r;
    float s = sin(angle * PI / 180);
    float c = cos(angle * PI / 180);
    r.X = objRadar_x * c + objRadar_y * s;
    r.Y = -objRadar_x * s + objRadar_y * c;
    return r;
}

// 投影：改成"每个关节用自己真实的透视除数"，与 hook 的 UeTools.h 完全同构（用 px/py 作半宽半高）
// 第三个参数 ViewW 保留以兼容 draw_Gui 现有调用，但内部不再使用
Vector2A WorldToScreen(Vector3A obj, float matrix[16], float ViewW)
{
    (void)ViewW;
    float camear = matrix[3] * obj.X + matrix[7] * obj.Y + matrix[11] * obj.Z + matrix[15];
    if (camear < 0.001f) camear = 0.001f;
    float x = px + (matrix[0] * obj.X + matrix[4] * obj.Y + matrix[8] * obj.Z + matrix[12]) / camear * px;
    float y = py - (matrix[1] * obj.X + matrix[5] * obj.Y + matrix[9] * obj.Z + matrix[13]) / camear * py;
    return Vector2A(x, y);
}

Vector3A MarixToVector(FMatrix m) { return Vector3A(m.M[3][0], m.M[3][1], m.M[3][2]); }

FMatrix MatrixMulti(FMatrix m1, FMatrix m2)
{
    FMatrix r = FMatrix();
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            for (int k = 0; k < 4; k++)
                r.M[i][j] += m1.M[i][k] * m2.M[k][j];
    return r;
}

FMatrix TransformToMatrix(FTransform t)
{
    FMatrix m;
    m.M[3][0] = t.Translation.X;
    m.M[3][1] = t.Translation.Y;
    m.M[3][2] = t.Translation.Z;
    float x2 = t.Rotation.X + t.Rotation.X;
    float y2 = t.Rotation.Y + t.Rotation.Y;
    float z2 = t.Rotation.Z + t.Rotation.Z;
    float xx2 = t.Rotation.X * x2;
    float yy2 = t.Rotation.Y * y2;
    float zz2 = t.Rotation.Z * z2;
    m.M[0][0] = (1 - (yy2 + zz2)) * t.Scale3D.X;
    m.M[1][1] = (1 - (xx2 + zz2)) * t.Scale3D.Y;
    m.M[2][2] = (1 - (xx2 + yy2)) * t.Scale3D.Z;
    float yz2 = t.Rotation.Y * z2;
    float wx2 = t.Rotation.W * x2;
    m.M[2][1] = (yz2 - wx2) * t.Scale3D.Z;
    m.M[1][2] = (yz2 + wx2) * t.Scale3D.Y;
    float xy2 = t.Rotation.X * y2;
    float wz2 = t.Rotation.W * z2;
    m.M[1][0] = (xy2 - wz2) * t.Scale3D.Y;
    m.M[0][1] = (xy2 + wz2) * t.Scale3D.X;
    float xz2 = t.Rotation.X * z2;
    float wy2 = t.Rotation.W * y2;
    m.M[2][0] = (xz2 + wy2) * t.Scale3D.Z;
    m.M[0][2] = (xz2 - wy2) * t.Scale3D.X;
    m.M[0][3] = 0; m.M[1][3] = 0; m.M[2][3] = 0; m.M[3][3] = 1;
    return m;
}

// 读 44 字节，现在 sizeof(FTransform)==44，Scale3D 不再错位
FTransform getBone(unsigned long addr)
{
    FTransform t;
    driver->read(addr, &t, sizeof(FTransform));   // = 44
    return t;
}

struct D3DXMATRIX {
    float _11, _12, _13, _14, _21, _22, _23, _24, _31, _32, _33, _34, _41, _42, _43, _44;
};
#endif