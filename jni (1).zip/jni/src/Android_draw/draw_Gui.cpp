#include "draw.h"
#include "My_font/zh_Font.h"
#include "读写.h"
#include "UeTool.h"
#include "绘图.h"
#include "paradise_api.h"
#include <dirent.h>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <cmath>

static long 类地址 = 0;
static bool 忽略人机 = false;
static int  g_bone_idx_off = 1;   // 骨骼索引整体偏移旋钮: 默认0=对齐Main.cpp; 还偏一格就拖+1/-1

void DrawInit() {
    if (初始化) return;
    pid = getPID("com.rekoo.pubgm");
    if (pid <= 0) { printf("游戏未启动\n"); return; }
    libbase = getModuleBase("libUE4.so");
    if (libbase <= 0) { printf("libUE4.so 未找到\n"); return; }
    初始化 = true;
    printf("初始化成功! libUE4: %lx, pid: %d\n", libbase, pid);
}

void UpdateGameData() {
    if (!初始化) return;
    Matrix = driver->read<uint64_t>(driver->read<uint64_t>(libbase + 0xf1d5f70) + 0xC0) + 0x590;
    Gname = driver->read<uint64_t>(driver->read<uint64_t>(libbase + 0xec73720) + 0x110);
    类地址 = Gname;
    Uworld = driver->read<uint64_t>(driver->read<uint64_t>(driver->read<uint64_t>(libbase + 0xf1fb900) + 0x810) + 0x78);
    Uleve = driver->read<uint64_t>(Uworld + 0x30);
    Arrayaddr = driver->read<uint64_t>(Uleve + 0xA0);
    Count = driver->read<int>(Uleve + 0xA8);
    MySelf = driver->read<uint64_t>(
        driver->read<uint64_t>(
            driver->read<uint64_t>(
                driver->read<uint64_t>(Uworld + 0x38) + 0x78
            ) + 0x30
        ) + 0x28c8
    );
    memset(matrix, 0, 16);
    driver->read((uintptr_t)Matrix, matrix, 16 * 4);
}
float bottom;
        if (DrawIo[4] && 骨骼有效) {
            if (Left_Ankle.Y < Right_Ankle.Y) bottom = Right_Ankle.Y + W / 10;
            else bottom = Left_Ankle.Y + W / 10;
        } else {
            bottom = BOTTOM;
        }
        if (DrawIo[2]) {
            char distBuf[16];
            snprintf(distBuf, sizeof(distBuf), "%d", (int)Distance);
            auto textSize = ImGui::CalcTextSize(distBuf, NULL, 25);
            draw->AddText(NULL, 30, ImVec2(Head.X - (textSize.x / 2), TOP - 30), ImColor(255, 255, 255), distBuf);
        }
        if (DrawIo[1]) draw->AddRect(ImVec2(X, TOP), ImVec2(X + W, BOTTOM), BoxColor, 0, 0, 1.5f);
        if (DrawIo[3]) draw->AddLine(ImVec2(px, 130), ImVec2(r_x, TOP), ImColor(255, 0, 0), 1.0f);
        if (DrawIo[7]) {
            char buf[32]; sprintf(buf, "0x%lx", Objaddr);
            draw->AddText(ImVec2(MIDDLE, BOTTOM), ImColor(239, 241, 245), buf);
        }
        if (DrawIo[4] && 骨骼有效) {
            draw->AddCircle(ImVec2(Head.X, Head.Y), W / 5, BoneColor, 0);
            draw->AddLine(ImVec2(Head.X, Head.Y), ImVec2(Chest.X, Chest.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Chest.X, Chest.Y), ImVec2(Pelvis.X, Pelvis.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Chest.X, Chest.Y), ImVec2(Left_Shoulder.X, Left_Shoulder.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Chest.X, Chest.Y), ImVec2(Right_Shoulder.X, Right_Shoulder.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Left_Shoulder.X, Left_Shoulder.Y), ImVec2(Left_Elbow.X, Left_Elbow.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Right_Shoulder.X, Right_Shoulder.Y), ImVec2(Right_Elbow.X, Right_Elbow.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Left_Elbow.X, Left_Elbow.Y), ImVec2(Left_Wrist.X, Left_Wrist.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Right_Elbow.X, Right_Elbow.Y), ImVec2(Right_Wrist.X, Right_Wrist.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Pelvis.X, Pelvis.Y), ImVec2(Left_Thigh.X, Left_Thigh.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Pelvis.X, Pelvis.Y), ImVec2(Right_Thigh.X, Right_Thigh.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Left_Thigh.X, Left_Thigh.Y), ImVec2(Left_Knee.X, Left_Knee.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Right_Thigh.X, Right_Thigh.Y), ImVec2(Right_Knee.X, Right_Knee.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Left_Knee.X, Left_Knee.Y), ImVec2(Left_Ankle.X, Left_Ankle.Y), BoneColor, 2.5f);
            draw->AddLine(ImVec2(Right_Knee.X, Right_Knee.Y), ImVec2(Right_Ankle.X, Right_Ankle.Y), BoneColor, 2.5f);
        }
        if (DrawIo[5]) {
            getUTF8(PlayerName, driver->read<uint64_t>(Objaddr + 0x960));
            auto textSize = ImGui::CalcTextSize(PlayerName, NULL, 28);
            draw->AddText(NULL, 28, ImVec2(MIDDLE - 45, TOP - 55), ImColor(248, 248, 255), PlayerName);
        }
        if (DrawIo[6]) {
            float healthPercent = 最大血量 > 0 ? (当前血量 / 最大血量) : 0.0f;
            float barX = X, barY = TOP - 16 - 8, barWidth = W, barHeight = 8;
            draw->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth, barY + barHeight), ImColor(60, 60, 60));
            draw->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth * healthPercent, barY + barHeight), ImColor(10, 240, 10));
            char healthText[16];
            sprintf(healthText, "%.0f%%", healthPercent * 100);
            draw->AddText(ImVec2(barX + barWidth + 3, barY + (barHeight - ImGui::CalcTextSize(healthText).y) / 2), ImColor(255, 255, 255), healthText);
        }
    }
    if (PlayerCount > 0) {
        char countBuf[16];
        snprintf(countBuf, sizeof(countBuf), "%d", PlayerCount);
        draw->AddText(NULL, 50.0f, ImVec2(px, 50), IM_COL32(255, 0, 0, 255), countBuf);
    } else {
        draw->AddText(NULL, 50.0f, ImVec2(px, 50), IM_COL32(0, 255, 0, 255), "安全");
    }
}
void DrawPlayer(ImDrawList* draw) {
    if (!初始化 || MySelf == 0) return;
    int 自己队伍 = driver->read<int>(MySelf + 0x998);
    Vector3A Z;
    driver->read((uintptr_t)(driver->read<uint64_t>(MySelf + 0x208) + 0x1c8), &Z, sizeof(Z));
    PlayerCount = 0;
    for (int i = 0; i < Count; i++) {
        long int Objaddr = driver->read<uint64_t>(Arrayaddr + 0x8 * i);
        if (Objaddr <= 0xffff || Objaddr == 0 || Objaddr <= 0x10000000 || Objaddr % 4 != 0 || Objaddr >= 0x10000000000) continue;
        if (MySelf == Objaddr) continue;
        if (driver->read<float>(Objaddr + 0x2b78) != 479.5f) continue;
        int ClassID = driver->read<int>(Objaddr + 24);
        long FNameEntry = driver->read<uint64_t>(
            driver->read<uint64_t>(类地址 + (ClassID / 0x4000) * 0x8) + (ClassID % 0x4000) * 0x8
        );
        char ClassName[64] = "";
        driver->read((uintptr_t)(FNameEntry + 0xC), ClassName, 64);
        if (strstr(ClassName, "BPPawn_Escape_Raven") != 0 || strstr(ClassName, "BPPawn_Escape_UAV_C") != 0) continue;
        int 状态 = driver->read<int>(Objaddr + 0x1058);
        if (状态 == 1048592 || 状态 == 1048576) continue;
        int 敌人队伍 = driver->read<int>(Objaddr + 0x998);
        if (敌人队伍 == 自己队伍) continue;
        if (忽略人机) {
            int botFlag = driver->read<int>(Objaddr + 0xa59);
            if (敌人队伍 && (botFlag == 16842753 || botFlag == 16843009 || botFlag == 16843008)) continue;
        }
        float 当前血量 = driver->read<float>(Objaddr + 0xe60);
        float 最大血量 = driver->read<float>(Objaddr + 0xe64);
        if (最大血量 <= 0) continue;
        PlayerCount++;
        Vector3A D;
        driver->read((uintptr_t)(driver->read<uint64_t>(Objaddr + 0x208) + 0x1c8), &D, sizeof(D));
        float camera = matrix[3] * D.X + matrix[7] * D.Y + matrix[11] * D.Z + matrix[15];
        if (camera <= 0.001f) continue;
        float Distance = sqrt(pow(D.X - Z.X, 2) + pow(D.Y - Z.Y, 2) + pow(D.Z - Z.Z, 2)) * 0.01f;
        if (Distance > 500 || Distance <= 0) continue;
        float r_x = px + (matrix[0] * D.X + matrix[4] * D.Y + matrix[8] * D.Z + matrix[12]) / camera * px;
        float r_y = py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z - 5) + matrix[13]) / camera * py;
        float r_w = py - (matrix[1] * D.X + matrix[5] * D.Y + matrix[9] * (D.Z + 205) + matrix[13]) / camera * py;
        float W = (r_y - r_w) / 2;
        if (W <= 0) continue;
        float X = r_x - (r_y - r_w) / 4;
        float Y = r_y;
        float MIDDLE = X + W / 2;
        float BOTTOM = Y + W;
        float TOP = Y - W;

        Vector2A Head, Chest, Pelvis, Left_Shoulder, Right_Shoulder,
                 Left_Elbow, Right_Elbow, Left_Wrist, Right_Wrist,
                 Left_Thigh, Right_Thigh, Left_Knee, Right_Knee,
                 Left_Ankle, Right_Ankle;
        bool 骨骼有效 = false;
        if (DrawIo[4]) {
            long int Mesh = driver->read<uint64_t>(Objaddr + 0x510);
            long int Bone = 0;
            if (Mesh > 0xffff) Bone = driver->read<uint64_t>(Mesh + 0x9a8) + 0x30;   // ★对齐Main.cpp(原0x9a8)
            if (Mesh > 0xffff && Bone > 0xffff) {
                骨骼有效 = true;
                long int human = Mesh + 0x210;                                       // ★对齐Main.cpp(原0x210)
                FTransform meshtrans = getBone(human);
                FMatrix c2wMatrix = TransformToMatrix(meshtrans);
                auto GB = [&](int n){ return getBone(Bone + (n + g_bone_idx_off) * 48); };
                // 索引对齐Main.cpp人类rig: 头5 胸4 盆0 肩11/32 肘12/33 腕63/62 腿52/56 膝53/57 踝54/58
                Vector3A relLocation = MarixToVector(MatrixMulti(TransformToMatrix(GB(5)), c2wMatrix));
                relLocation.Z += 4;   // ★脖子补偿对齐Main.cpp(原+7)
                Head = WorldToScreen(relLocation, matrix, camera);
                Chest        = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(4)),  c2wMatrix)), matrix, camera);
                Pelvis       = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(0)),  c2wMatrix)), matrix, camera);
                Left_Shoulder  = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(11)), c2wMatrix)), matrix, camera);
                Right_Shoulder = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(32)), c2wMatrix)), matrix, camera);
                Left_Elbow     = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(12)), c2wMatrix)), matrix, camera);
                Right_Elbow    = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(33)), c2wMatrix)), matrix, camera);
                Left_Wrist     = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(63)), c2wMatrix)), matrix, camera);
                Right_Wrist    = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(62)), c2wMatrix)), matrix, camera);
                Left_Thigh   = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(52)), c2wMatrix)), matrix, camera);
                Right_Thigh  = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(56)), c2wMatrix)), matrix, camera);
                Left_Knee    = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(53)), c2wMatrix)), matrix, camera);
                Right_Knee   = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(57)), c2wMatrix)), matrix, camera);
                Left_Ankle   = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(54)), c2wMatrix)), matrix, camera);
                Right_Ankle  = WorldToScreen(MarixToVector(MatrixMulti(TransformToMatrix(GB(58)), c2wMatrix)), matrix, camera);
            }
        }void Layout_tick_UI(bool* main_thread_flag) {
    UpdateGameData();
    static bool show_another_window = false;
    {
        static float f = 0.0f;
        static int counter = 0;
        static int style_idx = 0;
        static ImVec4 clear_color = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
        ImGui::Begin("ImGui-UE4", main_thread_flag);
        if (::permeate_record_ini) {
            ImGui::SetWindowPos({ LastCoordinate.Pos_x, LastCoordinate.Pos_y });
            ImGui::SetWindowSize({ LastCoordinate.Size_x, LastCoordinate.Size_y });
            permeate_record_ini = false;
        }
        ImGui::Text("渲染模式 : %s, gui版本 : %s", graphics->RenderName, IMGUI_VERSION);
        if (ImGui::Combo("##主题", &style_idx, "白色主题\0蓝色主题\0紫色主题\0")) {
            switch (style_idx) {
                case 0: ImGui::StyleColorsLight(); break;
                case 1: ImGui::StyleColorsDark(); break;
                case 2: ImGui::StyleColorsClassic(); break;
            }
        }
        if (ImGui::Checkbox("过录制", &::permeate_record)) {
            ::permeate_record_ini = true;
        }
        if (ImGui::Button("初始化绘制", ImVec2(ImGui::GetContentRegionAvail().x, 50))) {
            DrawInit();
        }
        ImGui::ItemSize(ImVec2(0, 5));
        ImGui::Checkbox("显示方框", &DrawIo[1]);
        ImGui::SameLine(0, 40);
        ImGui::Checkbox("显示距离", &DrawIo[2]);
        ImGui::SameLine(0, 40);
        ImGui::Checkbox("显示射线", &DrawIo[3]);
        ImGui::Checkbox("显示骨骼", &DrawIo[4]);
        ImGui::SameLine(0, 20);
        ImGui::SliderInt("骨骼索引偏移", &g_bone_idx_off, -3, 3);
        ImGui::SameLine(0, 40);
        ImGui::Checkbox("显示信息", &DrawIo[5]);
        ImGui::SameLine(0, 40);
        ImGui::Checkbox("显示血量", &DrawIo[6]);
        ImGui::Checkbox("敌人地址", &DrawIo[7]);
        ImGui::SameLine(0, 40);
        ImGui::Checkbox("忽略人机", &忽略人机);
        ImGui::SliderFloat("刷新帧率调节", &FPS, 60.0f, 144.0f, "%.2f", 3);
        ImGui::BulletText("进程:%d", pid);
        ImGui::BulletText("矩阵:%lx", Matrix);
        ImGui::BulletText("自身结构:%lx", MySelf);
        ImGui::BulletText("世界:%lx", Arrayaddr);
        ImGui::BulletText("数量:%d", Count);
        ImGui::TextColored(ImVec4(1.0f, 0.0f, 1.0f, 1.0f), "应用平均 %.3f ms/frame (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
        g_window = ImGui::GetCurrentWindow();
        ImGui::End();
    }
}
        