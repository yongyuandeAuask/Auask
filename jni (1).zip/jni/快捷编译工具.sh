### aide快捷编译工具
## 开发者信息
# *思路来源 FuckError11(@FuckError11)
# *更新优化 FuckError11(@FuckError11)
# *上一版本 雪屹(@C_XueYi)
# *改进by币子 频道@asuka1314
##优化更新内容
# *套层gztmp 可在任意目录直接执行
# *修改编译后内容为`频道@asuka1314`
##使用说明
# *放到C++或其他项目jni目录
# *确保已经安装aide和ndk

##发布声明
# *官方Telegram频道 @ErrorKernel
# *开源改进频道 @asuka1314
# *开发者TG @FuckError11 & @C_XueYi
# *改进开源 @asuka1314
# *修改/转发请保留开发者信息！
# *修改/删除开发者信息全家死光！
### The following is the official script
[[ "$(id -u)" != "2000" && "$(id -u)" != "0" ]] && echo "\e[31m需求ROOT\e[0m" && exit

Pns=("com.idragoncheats.studio" "com.idragoncheats.studiopro" "com.goxome.aidestudio" "aidepro.top")  # 全部包名
Fd=()  # 找到的包名

for Pn in "${Pns[@]}"
do
    [ -e "/data/user/0/${Pn}/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build" ] && Fd+=("${Pn}")
done
[ ${#Fd[@]} -eq 0 ] && echo "\e[31m未找到ndk-build\e[0m" && exit 1
if [ ${#Fd[@]} != 1 ] ; then
    echo "\e[31m找到多个ndk-build，输入序号使用\e[0m"
    for i in "${!Fd[@]}"; do
        echo "\e[33m[$((i+1))]\e[90m ->\e[37m ${Fd[i]}\e[0m"
    done
    read Input
    if [[ $Input -ge 1 && $Input -le ${#Fd[@]} ]]; then
        UsePN="${Fd[$((Input-1))]}"
    else
        echo "\e[31m请输入1~${#Fd[@]}\e[0m"
        exit 1
    fi
else
    UsePN="${Fd[0]}"
fi

/data/user/0/${UsePN}/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build 2>&1

if [ $? -eq 0 ]; then
    echo "\e[32mMake Success\e[0m"
else
    echo "\e[31mMake Failed\e[0m"
    target_file="/data/user/0/${UsePN}/no_backup/ndksupport-1710240003/android-ndk-aide/build/core/setup-app.mk"
    if [ -f "$target_file" ]; then
        sed -i '1i SHELL := /system/bin/sh' "$target_file"
        echo "\e[33m编译出错 已在 $target_file 第一行添加 SHELL := /system/bin/sh 请重新启动\e[0m"
    else
        echo "\e[33m文件 $target_file 不存在，无法添加 请手动查找并添加\e[0m"
    fi
    exit 1
fi

elf_filename="libs/arm64-v8a/*" #你的二进制路径
you_shell="测试.sh" #生成路径
compression_level="9" #压缩级别
#@嘿嘿嘿

#shell部分base64
echo "IyEvc3lzdGVtL2Jpbi9zaApDUkMzMj00NApzZXQgLWUKdGFiPScJJwpubD0nCicKSUZTPSIgJHRh
YiRubCIKdW1hc2s9YHVtYXNrYAp1bWFzayA3NwpnenRtcGRpcj0KdHJhcCAncmVzPSQ/CiAgdGVz
dCAtbiAiJGd6dG1wZGlyIiAmJiBybSAtZnIgIiRnenRtcGRpciIKICAoZXhpdCAkcmVzKTsgZXhp
dCAkcmVzCicgMCAxIDIgMyA1IDEwIDEzIDE1CmNhc2UgJFRNUERJUiBpbgogIC8gfCAvKi8pIDs7
CiAgLyopIFRNUERJUj0kVE1QRElSLzs7CiAgKikgVE1QRElSPS9kYXRhL2xvY2FsL3RtcC87Owpl
c2FjCmlmIHR5cGUgbWt0ZW1wID4vZGV2L251bGwgMj4mMTsgdGhlbgogIGd6dG1wZGlyPWBta3Rl
bXAgLWQgIiR7VE1QRElSfWd6dG1wWFhYWFhYWFhYImAKZWxzZQogIGd6dG1wZGlyPSR7VE1QRElS
fWd6dG1wJCQ7IG1rZGlyICRnenRtcGRpcgpmaSB8fCB7IChleGl0IDI1Nik7IGV4aXQgMjU2OyB9
Cmd6dG1wPSRnenRtcGRpci8kMApjYXNlICQwIGluCi0qIHwgKi8qJwonKSBta2RpciAtcCAiJGd6
dG1wIiAmJiBybSAtciAiJGd6dG1wIjs7CiovKikgZ3p0bXA9JGd6dG1wZGlyL2BiYXNlbmFtZSAi
JDAiYDs7CmVzYWMgfHwgeyAoZXhpdCAyNTYpOyBleGl0IDI1NjsgfQpjYXNlIGBwcmludGYgJ1hc
bicgfCB0YWlsIC1uICsxIDI+L2Rldi9udWxsYCBpbgpYKSB0YWlsX249LW47OwoqKSB0YWlsX249
OzsKZXNhYwppZiB0YWlsICR0YWlsX24gKzQ0IDwiJDAiIHwgZ3ppcCAtY2QgPiAiJGd6dG1wIjsg
dGhlbgogIHVtYXNrICR1bWFzawogIGNobW9kIDc3NyAiJGd6dG1wIgogIChzbGVlcCA1OyBybSAt
ZnIgIiRnenRtcGRpciIpIDI+L2Rldi9udWxsICYKICAiJGd6dG1wIiAkezErIiRAIn07IHJlcz0k
PwplbHNlCiAgcHJpbnRmID4mMiAnJXNcbicgInpoZW5zaSAkMCIKICAoZXhpdCAyNTYpOyByZXM9
MjU2CmZpOyBleGl0ICRyZXMK" | base64 -d > $you_shell

gzip -c -$compression_level $elf_filename  | cat >> $you_shell

GREEN='\033[0;32m'
NC='\033[0m'
echo -e "${GREEN}完成@asuka1314.${NC}"
echo -e "${GREEN}完成@asuka1314.${NC}"
echo "\e[33m开始编译\n绘香不是絵香\n绘香不是絵香\n绘香不是絵香\n\e[0m "
echo "\e[32m绘香不是絵香\n绘香不是絵香\n绘香不是絵香\n\e[0m "

tmp=/data/local/tmp
rm -rf ${tmp}/币子快捷编译工具 && mv ./libs/**/* ${tmp}/币子快捷编译工具 && chmod +x ${tmp}/币子快捷编译工具
echo "\n\e[33m开始运行\e[0m\n"
${tmp}/币子快捷编译工具
